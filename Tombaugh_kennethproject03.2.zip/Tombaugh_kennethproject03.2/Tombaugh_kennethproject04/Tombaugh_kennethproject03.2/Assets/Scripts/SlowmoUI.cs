﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SlowmoUI : MonoBehaviour
{

    public GameObject sMo;
    // Start is called before the first frame update
    public static bool SlowMo = false;

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (SlowMo)
            {
                Normal();
            }
            else
            {
                Slow();
            }
        }
    }

    void Normal()
    {
        sMo.SetActive(false);
        Time.timeScale = 1f;
        SlowMo = false;
    }

    void Slow()
    {
        sMo.SetActive(true);
        Time.timeScale = Time.timeScale == 1 ? .2f : 1;
        SlowMo = true;
    }
        

}
