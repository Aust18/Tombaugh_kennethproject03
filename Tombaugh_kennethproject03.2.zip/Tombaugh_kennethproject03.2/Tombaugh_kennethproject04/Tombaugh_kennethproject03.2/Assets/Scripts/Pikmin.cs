﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Pikmin : MonoBehaviour
{

    [SerializeField] GameObject targ;
    void Update()
    {
        transform.position = Vector3.MoveTowards(transform.position, targ.transform.position, .03f);
    }

}
